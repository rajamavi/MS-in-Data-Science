SELECT *
FROM `finance.fraud_data`
ORDER BY amount desc
LIMIT 10